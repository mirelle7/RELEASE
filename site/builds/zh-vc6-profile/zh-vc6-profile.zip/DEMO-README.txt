PLACEHOLDER for build zh-vc6-profile

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset vc6-profile -DRTS_BUILD_GENERALS=OFF -DRTS_BUILD_ZEROHOUR=ON
