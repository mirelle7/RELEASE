PLACEHOLDER for build generals-vc6-release

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset vc6 -DRTS_BUILD_GENERALS=ON -DRTS_BUILD_ZEROHOUR=OFF
