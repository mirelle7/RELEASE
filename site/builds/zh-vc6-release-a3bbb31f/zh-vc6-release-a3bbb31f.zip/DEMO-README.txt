PLACEHOLDER for build zh-vc6-release-a3bbb31f

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset vc6 -DRTS_BUILD_GENERALS=OFF -DRTS_BUILD_ZEROHOUR=ON -DRTS_DEBUG_MULTI_INSTANCE=ON
