PLACEHOLDER for build zh-msvc-debug

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset win32-debug -DRTS_BUILD_GENERALS=OFF -DRTS_BUILD_ZEROHOUR=ON
