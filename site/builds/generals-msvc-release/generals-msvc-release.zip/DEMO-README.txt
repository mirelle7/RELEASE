PLACEHOLDER for build generals-msvc-release

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset win32 -DRTS_BUILD_GENERALS=ON -DRTS_BUILD_ZEROHOUR=OFF
