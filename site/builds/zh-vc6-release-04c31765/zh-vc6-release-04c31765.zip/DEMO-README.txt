PLACEHOLDER for build zh-vc6-release-04c31765

This is a demo. This archive contains no executable.
A real build of this configuration would be produced with:

  cmake --preset vc6 -DRTS_BUILD_GENERALS=OFF -DRTS_BUILD_ZEROHOUR=ON -DRTS_BUILD_OPTION_RETAIL_COMPATIBLE_GAME=OFF
